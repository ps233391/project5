<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Band extends Model
{
    use HasFactory;

    public $table = "bands";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array<string>
     */
    protected $fillable = ['name', 'genre', 'founded', 'active_til'];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array<string>|bool
     */
    // protected $guarded = ['*'];

    /**
     * Get the Albums on the coressponding band
     */
    public function Albums() 
    {
        return $this->hasMany(Album::class);
    }
}
