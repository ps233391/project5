<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Album extends Model
{
    use HasFactory;

    public $table = "albums";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array<string>
     */
    protected $fillable = ['name', 'year', 'times_sold'];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array<string>|bool
     */
    // protected $guarded = ['*'];

    /**
     * Get the Songs on the coresponding album
     */
    public function Songs(): BelongsToMany
    {
        return $this->belongsToMany(Song::class);
    }

    /**
     * Get the Band on the coresponding album
     */
    public function Bands()
    {
        return $this->hasOne(Band::class);
    }
}