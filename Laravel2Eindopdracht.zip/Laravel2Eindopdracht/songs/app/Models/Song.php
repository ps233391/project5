<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Song extends Model
{
    use HasFactory;

    public $table = "songs";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array<string>
     */
    protected $fillable = ['title', 'band'];

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array<string>|bool
     */
    // protected $guarded = ['*'];

    /**
    * Get the Album on the coresponding song
    */
    public function Albums(): BelongsToMany
    {
        return $this->belongsToMany(Album::class);
    }
}
