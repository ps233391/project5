<?php

use App\Http\Controllers\AlbumController;
use App\Http\Controllers\AlbumSongController;
use App\Http\Controllers\BandController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SongController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';


/*=============
    SONGS
=============*/
Route::resource('songs', SongController::class)->middleware('auth')->except('index', 'show');
Route::resource('songs', SongController::class)->only('index', 'show');

/*=============
    BANDS
=============*/
Route::resource('bands', BandController::class)->middleware('auth')->except('index', 'show');
Route::resource('bands', BandController::class)->only('index', 'show');

/*=============
    ALBUMS
=============*/
Route::resource('albums', AlbumController::class)->middleware('auth')->except('index', 'show');
Route::resource('albums', AlbumController::class)->only('index', 'show');

/*================
    ALBUM_SONG
==================*/
Route::put('/albums/{album}/songs/{song}', [AlbumSongController::class, 'store'])->name('album_song.store');
Route::delete('/albums/{album}/songs/{song}', [AlbumSongController::class, 'destroy'])->name('album_song.destroy');