<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - index</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div>
        <h2>Album lijst</h2>
        <ul>
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('albums.show', ['album' => $album->id])); ?>"><?php echo e($album->name); ?></a> - <?php echo e($album->times_sold); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php if(Auth::check() == true): ?>
    <div>
        <a href="<?php echo e(route('albums.create')); ?>">Nieuw album</a>
    </div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\tjgte\Projecten\School\Laravel\Module_2\week-4\songs\resources\views/albums/index.blade.php ENDPATH**/ ?>