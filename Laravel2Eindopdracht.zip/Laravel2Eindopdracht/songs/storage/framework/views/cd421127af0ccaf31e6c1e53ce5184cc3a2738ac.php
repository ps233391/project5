<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div style="display: flex; flex-direction: row;">
        <div style="display: flex; flex-direction: column;">
            <h2>Details over album: <?php echo e($album->name); ?></h2>
            <ul>
                <li>Title: <?php echo e($album->name); ?></li>
                <li>Band: <a href="<?php echo e(route('bands.show', ['band' => $band->id])); ?>"><?php echo e($band->name); ?></a></li>
                <li>Year of release: <?php echo e($album->year); ?></li>
                <li>Times sold: <?php echo e($album->times_sold); ?></li>
            </ul>
            <?php if(Auth::check() == true): ?>
                <div style="display: flex; gap: 2rem;">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                    <a href="<?php echo e(route('albums.edit', ['album' => $album->id])); ?>">Update</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-3\songs\resources\views/albums/details.blade.php ENDPATH**/ ?>