<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - index</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div>
        <h2>band aanpassen</h2>
        <h3>de band die je aan gaat passen is:</h3>

        <p>Name: <?php echo e($band->name); ?><br>
        Genre: <?php echo e($band->genre); ?><br>
        Active til: <?php echo e($band->active_til); ?><br>
        Aangemaakt op: <?php echo e($band->created_at); ?></p>
    
        <form action="bands.index" method="POST" style="display: flex; flex-direction: column; width: 200px;">
            <label for="title">Name</label>
            <input id="title" type="text"></input>
            <label for="singer">Genre</label>
            <input id="singer" type="text"></input>
            <label for="singer">Active til</label>
            <input id="singer" type="text"></input>
            <label for="create">Aangemaakt op</label>
            <input id="create" type="text"></input>
            <br>
            <button type="submit">Opslaan</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-4\songs\resources\views/albums/edit.blade.php ENDPATH**/ ?>