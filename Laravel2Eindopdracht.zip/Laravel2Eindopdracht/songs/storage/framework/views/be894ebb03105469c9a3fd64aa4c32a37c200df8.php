<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>songs - index</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div>
        <form action="<?php echo e(route('songs.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h2>Add a new song to the list!</h2>
            <label for="title">Titel</label><br>
            <input id="title" name="title" type="text" placeholder="Titel"></input>
            <br>
            <br>
            <button type="submit">Voeg toe</button>
        </form>
    </div>
    <div>
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($song['name']); ?></p>
            <p><?php echo e($song['artist']); ?></p>
            <p><?php echo e($song['url']); ?></p>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-4\songs\resources\views/songs/create.blade.php ENDPATH**/ ?>