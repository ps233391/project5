<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bands - index</title>
</head>
<body>
    <div>
        <h2>Band lijst</h2>
        <ul>
            <?php $__currentLoopData = $bands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $band): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($band->name); ?> - <a href="<?php echo e(route('bands.show', ['id' => $band->id])); ?>">about</a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-3\songs\resources\views/bands/bands.blade.php ENDPATH**/ ?>