<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Songs - index</title>
</head>
<body>
    <div>
        <h2>Liederen lijst</h2>
        <ul>
            <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('songs.show', ['id' => $song->id])); ?>"><?php echo e($song->title); ?></a> - <a href="<?php echo e(route('bands.show', ['id' => $song->band])); ?>"><?php echo e($song->band); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-3\songs\resources\views/songs/songs.blade.php ENDPATH**/ ?>