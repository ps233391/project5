<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Songs - edit</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>

    <div>
        <h2>Nummer aanpassen</h2>
        <h3>het nummer wat je aan gaat passen is:</h3>

        <p>Title: <?php echo e($song->title); ?><br>
        Aangemaakt op: <?php echo e($song->created_at); ?></p>
    
        <form action="<?php echo e(route('songs.update', $song->id)); ?>" method="POST" style="display: flex; flex-direction: column; width: 200px;">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <label for="title">Titel</label>
            <input id="title" name="title" type="text"></input>
            <br>
            <button type="submit">Opslaan</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-4\songs\resources\views/songs/edit.blade.php ENDPATH**/ ?>