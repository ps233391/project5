<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>songs - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div>
        <h2>Details over song: <?php echo e($song->title); ?></h2>
        <ul>
            <li>Title: <?php echo e($song->title); ?></li>
            <li>Aangemaakt op: <?php echo e($song->created_at); ?></li>
            <li>laatst aangepast op: <?php echo e($song->updated_at); ?></li>
        </ul>
        <?php if(Auth::check() == true): ?>
            <form action="<?php echo e(route('songs.destroy', $song->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">Delete</button>
            </form>
            <form action="" method="put">
                <a href="<?php echo e(route('songs.edit', ['song' => $song->id])); ?>">update song</a>
            </form>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-4\songs\resources\views/songs/details.blade.php ENDPATH**/ ?>