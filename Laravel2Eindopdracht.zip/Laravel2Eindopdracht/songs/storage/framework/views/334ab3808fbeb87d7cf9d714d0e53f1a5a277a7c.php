<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
        form {display: flex; flex-direction: column; width: 350px;}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div>
        <form action="#" method="POST">
            <?php echo csrf_field(); ?>
            <h2>add a new album to the list!</h2>
            <label for="title">Name</label>
            <input id="title" name="title" type="text" placeholder="Titel"></input>
            <label for="singer">Year</label>
            <input id="singer" name="singer" type="text" placeholder="Artiest"></input>
            <label for="sold">Times sold</label>
            <input id="singer" name="sold" type="text" placeholder="100000"></input>
            <br>
            <br>
            <button type="submit">Voeg toe</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\Projecten\School\Laravel\Module_2\week-4\songs\resources\views/albums/create.blade.php ENDPATH**/ ?>