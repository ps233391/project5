<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>albums - index</title>
</head>
<body>
    <div>
        <h2>Album lijst</h2>
        <ul>
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('albums.show', ['id' => $album->id])); ?>"><?php echo e($album->name); ?></a> - <?php echo e($album->times_sold); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</body>
</html><?php /**PATH C:\Users\tjgte\school\laravel2\week-3\songs\resources\views/albums/albums.blade.php ENDPATH**/ ?>