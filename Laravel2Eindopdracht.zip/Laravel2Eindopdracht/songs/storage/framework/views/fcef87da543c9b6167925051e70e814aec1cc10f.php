<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bands - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="<?php echo e(route('songs.index')); ?>">Liedjes</a>
            <a href="<?php echo e(route('bands.index')); ?>">Bands</a>
            <a href="<?php echo e(route('albums.index')); ?>">Albums</a>
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </div>
    </header>
    <div style="display: flex; flex-direction: row; gap: 5em;">
        <div>
            <h2>Details over band: <?php echo e($band->name); ?></h2>
            <ul>
                <li>Name: <?php echo e($band->name); ?></li>
                <li>genre: <?php echo e($band->genre); ?></li>
                <li>founded in: <?php echo e($band->founded); ?></li>
                <li>active til: <?php echo e($band->active_til); ?></li>
            </ul>
            <br>
            <?php if(Auth::check() == true): ?>
                <div style="display:flex; flex-direction: row; gap: 2em;">
                    <form action="<?php echo e(route('bands.destroy', $band->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                    <a href="<?php echo e(route('bands.edit', ['band' => $band->id])); ?>">update band</a>
                </div>
            <?php endif; ?>   
        </div>
        <div>
            <h2>Albums:</h2>
            <ul>
                <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($album->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Rik van der Zande\laravel\Laravel2Eindopdracht\songs\resources\views/bands/details.blade.php ENDPATH**/ ?>