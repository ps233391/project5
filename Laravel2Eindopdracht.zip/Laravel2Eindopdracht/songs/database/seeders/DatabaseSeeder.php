<?php
namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Album;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([BandSeeder::class]);
        $this->call([AlbumSeeder::class]);
        $this->call([SongSeeder::class]);
        $this->call([AlbumSongSeeder::class]);
        $this->call([UserSeeder::class]);
    }
}
