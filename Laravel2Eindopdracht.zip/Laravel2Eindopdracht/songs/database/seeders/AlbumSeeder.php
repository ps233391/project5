<?php
namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AlbumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('albums')->insert([
            'name' => 'Goud',
            'year' => '2022',
            'times_sold' => '10000',
            'band_id' => '1',
        ]);
        DB::table('albums')->insert([
            'name' => 'Test1',
            'year' => '1919',
            'times_sold' => '123456789',
            'band_id' => '2',
        ]);
        DB::table('albums')->insert([
            'name' => '100 keer',
            'year' => '2022',
            'times_sold' => '28300000',
            'band_id' => '1',
        ]);
        DB::table('albums')->insert([
            'name' => 'test2',
            'year' => '1919',
            'times_sold' => '2400000',
            'band_id' => '2',
        ]);
        DB::table('albums')->insert([
            'name' => 'Martijn',
            'year' => '2023',
            'times_sold' => '100000',
            'band_id' => '3',
        ]);
        DB::table('albums')->insert([
            'name' => 'Kali',
            'year' => '1919',
            'times_sold' => '2400000',
            'band_id' => '5',
        ]);
        DB::table('albums')->insert([
            'name' => 'Brabant',
            'year' => '2023',
            'times_sold' => '100000',
            'band_id' => '4',
        ]);
    }
}