<?php
namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
class BandSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('bands')->insert([
            'name' => 'Suzan en freek',
            'genre' => 'nederlandse meezinger',
            'founded' => '2022',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
        DB::table('bands')->insert([
            'name' => 'Testen',
            'genre' => 'test test',
            'founded' => '1919',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
        DB::table('bands')->insert([
            'name' => 'Martijn Koster',
            'genre' => 'irritant',
            'founded' => '2021',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
        DB::table('bands')->insert([
            'name' => 'Guus meeuwis',
            'genre' => 'Brabantse muziek',
            'founded' => '2005',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
        DB::table('bands')->insert([
            'name' => 'Django wagner',
            'genre' => 'Feest muziek',
            'founded' => '2014',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);
    }
}
