<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bands - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="{{route('songs.index')}}">Liedjes</a>
            <a href="{{route('bands.index')}}">Bands</a>
            <a href="{{route('albums.index')}}">Albums</a>
            <a href="{{route('dashboard')}}">Dashboard</a>
        </div>
    </header>
    <div style="display: flex; flex-direction: row; gap: 5em;">
        <div>
            <h2>Details over band: {{$band->name}}</h2>
            <ul>
                <li>Name: {{$band->name}}</li>
                <li>genre: {{$band->genre}}</li>
                <li>founded in: {{$band->founded}}</li>
                <li>active til: {{$band->active_til}}</li>
            </ul>
            <br>
            @if (Auth::check() == true)
                <div style="display:flex; flex-direction: row; gap: 2em;">
                    <form action="{{ route('bands.destroy', $band->id) }}" method="post">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                    <a href="{{route('bands.edit', ['band' => $band->id]) }}">update band</a>
                </div>
            @endif   
        </div>
        <div>
            <h2>Albums:</h2>
            <ul>
                @foreach($albums as $album)
                    <li>{{$album->name}}</li>
                @endforeach
            </ul>
        </div>
    </div>
</body>
</html>