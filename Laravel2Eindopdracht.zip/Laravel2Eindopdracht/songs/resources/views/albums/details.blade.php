<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - details</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        div {margin-inline: 20px}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="{{route('songs.index')}}">Songs</a>
            <a href="{{route('bands.index')}}">Bands</a>
            <a href="{{route('albums.index')}}">Albums</a>
            <a href="{{route('dashboard')}}">Dashboard</a>
        </div>
    </header>
    <div style="display: flex; flex-direction: row;">
        <div style="display: flex; flex-direction: column;">
            <h2>Details over album: {{$album->name}}</h2>
            <ul>
                <li>Titel: {{$album->name}}</li>
                <li>Band: <a href="{{route('bands.show', ['band' => $band->id]) }}">{{$band->name}}</a></li>
                <li>Jaar van uitkomen: {{$album->year}}</li>
                <li>Keren verkocht: {{$album->times_sold}}</li>
            </ul>
            @if (Auth::check() == true)
                <div style="display: flex; gap: 2rem;">
                    <form action="" method="post">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Verwijderen</button>
                    </form>
                    <a href="{{route('albums.edit', ['album' => $album->id])}}">Update</a>
                </div>
            @endif
        </div>
        <div>
            <h2>Songs van dit album: </h2>
            <ul>
                @foreach ($album->songs as $song)
                    <li><span>{{$song->title}}</span></li>
                @endforeach
            </ul>
        </div>
        
    </div>
</body>
</html>