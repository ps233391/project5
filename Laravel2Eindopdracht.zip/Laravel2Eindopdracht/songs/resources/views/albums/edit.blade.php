<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>albums - index</title>
    <style>
        body {padding: none; margin: 0;}
        header {width: 100%; background-color: black;}
        header > div {padding-block: 20px; margin-inline: 20px;}
        header > div > a {color: white; margin-left: 25px;}
        .wrapper {margin-inline: 20px; display: flex; gap: 5.5rem;}
        li {margin-block: 5px;}
        li > button {margin-left: 10px;}
    </style>
</head>
<body>
    <header>
        <div>
            <a href="{{route('songs.index')}}">Songs</a>
            <a href="{{route('bands.index')}}">Bands</a>
            <a href="{{route('albums.index')}}">Albums</a>
            <a href="{{route('dashboard')}}">Dashboard</a>
        </div>
    </header>
    <div class="wrapper">
        <div>
            <h2>album aanpassen</h2>
            <h3>het album wat je aan gaat passen:</h3>

            <p>Name: {{$album->name}}<br>
            Genre: {{$band->genre}}<br>
            Active til: {{$band->active_til}}<br>
            Aangemaakt op: {{$band->created_at}}</p>
    
            <form action="bands.index" method="POST" style="display: flex; flex-direction: column; width: 200px;">
                <label for="title">Name</label>
                <input id="title" type="text"></input>
                <label for="singer">Genre</label>
                <input id="singer" type="text"></input>
                <label for="singer">Active til</label>
                <input id="singer" type="text"></input>
                <label for="create">Aangemaakt op</label>
                <input id="create" type="text"></input>
                <br>
                <button type="submit">Opslaan</button>
            </form>
        </div>

        <div>
            <h2>Nummers koppelen</h2>
            <ul>
                @foreach ($songs as $song)
                    <form action="{{ route('album_song.store', ['album' => $album->id , 'song' => $song->id]) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <li><span>{{$song->title}}</span><button type="submit">+</button></li>
                    </form>
                @endforeach
            </ul>
        </div>

        <div>
            <h2>Gekoppelde nummers</h2>
            <ul>
                @foreach ($album->songs as $album_song)
                    <form action="{{ route('album_song.destroy', ['album' => $album->id, 'song' => $album_song->id]) }}" method="post">
                        @csrf
                        @method('DELETE')
                        <li><span>{{$album_song->title}}</span><button type="submit">-</button></li>
                    </form>
                @endforeach
            </ul>
        </div>
    </div>
</body>
</html>